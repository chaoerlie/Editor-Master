package Pre_Editor;

import javax.swing.*;


public class Calculate {
    //private CurrentLineInfo currentLineInfo;
    private static int isInt = 1;
    private static int ASD;
    private static int choice = 0;
    private CalculateInterface calculateMode;
    //choice 为选择答案形式：0->auto
//    						1->integer
//    						2->float
    public Calculate(Pre_Editor editor) {

        String originline = editor.workingManager.getCurrentWritingArea().getCurrentLineInfo().getLineText();

        String validline = "";
        if (originline.charAt(originline.length() - 1) == '=') {
            try {
                validline = originline.substring(0, originline.length() - 1);


                int caretPosition = editor.workingManager.getCurrentWritingArea().getCurrentLineInfo().getCaretPosition();
                if (choice == 1) {
                    //插入整数

                    calculateMode = new calculateInt();
                    editor.workingManager.getCurrentWritingArea().textArea.replaceRange(calculateMode.calc(validline),
                            caretPosition, caretPosition);
                } else if (choice == 2) {
                    calculateMode = new calculateFloat();
                    editor.workingManager.getCurrentWritingArea().textArea.replaceRange(calculateMode.calc(validline),
                            caretPosition, caretPosition);
                } else
                //auto
                {
                    calculateMode = new calclateAuto();
                    editor.workingManager.getCurrentWritingArea().textArea.replaceRange(calculateMode.calc(validline),
                            caretPosition, caretPosition);
                }
            } catch (Exception e) {
                
                JOptionPane.showMessageDialog(
                        editor.mainframe,
                        "Not compliant",
                        
                        "Error Message",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        } else {
            JOptionPane.showMessageDialog(
                    editor.mainframe,
                    "Not compliant",
                    //TODO
                    "Error Message",
                    JOptionPane.ERROR_MESSAGE
            );

        }
    }

    public Boolean isint(String originString) {
        for (int i = 0; i < originString.length(); i++) {
            if (originString.charAt(i) == '/' || originString.charAt(i) == '.') {
                return false;
            }
        }
        return true;
    }

}