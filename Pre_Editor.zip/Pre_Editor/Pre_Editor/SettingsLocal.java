package Pre_Editor;

/**
 * @author KKKZOZ
 */
public class SettingsLocal {

}
