package Pre_Editor;

import javax.swing.*;

public class CustomizeUI {

    public JPanel parentPanel;
    private final Pre_Editor editor;

    public CustomizeUI(Pre_Editor editor) {
        this.editor = editor;
    }
}